import numpy as np
import skfuzzy as fuzz
import matplotlib.pyplot as plt
from skfuzzy import control as ctrl

#Variaveis de Entrada (Antecedent)
comer = ctrl.Antecedent(np.arange(0, 9, 1), 'comer')
exercicio_semana = ctrl.Antecedent(np.arange(0, 8, 1), 'exercicio')

#Variaveis de saída (Consequent)
peso = ctrl.Consequent(np.arange(0, 11, 1), 'Peso')

# automf -> Atribuição de categorias automaticamente

comer['Pouco'] = fuzz.trapmf(comer.universe, [-1, -1, 2, 4])
comer['Razoável'] = fuzz.trapmf(comer.universe, [2, 4, 5, 7])
comer['Bastante'] = fuzz.trapmf(comer.universe, [5, 7, 15, 30])

exercicio_semana['Poucos'] = fuzz.trapmf(exercicio_semana.universe, [-1, -1, 2, 3])
exercicio_semana['Alguns'] = fuzz.trapmf(exercicio_semana.universe, [2, 3, 4, 6])
exercicio_semana['Todos'] = fuzz.trapmf(exercicio_semana.universe, [5, 6, 8, 10])



# atribuicao sem o automf TRAPEZIO
peso['Peso Leve'] = fuzz.trapmf(peso.universe, [-1, -1, 4, 6])
peso['Peso Médio'] = fuzz.trapmf(peso.universe, [4, 6, 8, 10])
peso['Pesado'] = fuzz.trapmf(peso.universe, [8, 10, 15, 30])

#Visualizando as variáveis
#comer.view()
#exercicio_semana.view()

#Criando as regras
regra_1 = ctrl.Rule(comer['Bastante'] & exercicio_semana['Poucos'], peso['Pesado'])
regra_2 = ctrl.Rule(comer['Bastante'] & exercicio_semana['Alguns'], peso['Peso Médio'])
regra_3 = ctrl.Rule(comer['Pouco'] | exercicio_semana['Todos'], peso['Peso Leve'])
regra_4 = ctrl.Rule(comer['Razoável'] & exercicio_semana['Alguns'], peso['Peso Médio'])
regra_5 = ctrl.Rule(comer['Razoável'] & exercicio_semana['Poucos'], peso['Peso Médio'])

controlador = ctrl.ControlSystem([regra_1, regra_2, regra_3, regra_4, regra_5])

#Simulando
CalculoPeso = ctrl.ControlSystemSimulation(controlador)

notaComer = int(input('O quanto come: '))
notaExercicio = int(input('O quanto se exercita: '))
CalculoPeso.input['comer'] = notaComer
CalculoPeso.input['exercicio'] = notaExercicio
CalculoPeso.compute()

valorPeso = CalculoPeso.output['Peso']

print("\nComer %d \nExercicio %d \nPeso %5.2f" %(
        notaComer,
        notaExercicio,
        valorPeso))


comer.view(sim=CalculoPeso)
exercicio_semana.view(sim=CalculoPeso)
peso.view(sim=CalculoPeso)

plt.show()




"""
# atribuicao sem o automf TRIANGULO
gorjeta['minima'] = fuzz.trimf(gorjeta.universe, [-1, 0, 1])
gorjeta['baixa'] = fuzz.trimf(gorjeta.universe, [0, 3, 15])
gorjeta['media'] = fuzz.trimf(gorjeta.universe, [1, 15, 30])
gorjeta['alta'] = fuzz.trimf(gorjeta.universe, [15, 30, 45])

# atribuicao sem o automf GAUSS
gorjeta['minima'] = fuzz.gaussmf(gorjeta.universe, 0,.1)
gorjeta['baixa'] = fuzz.gaussmf(gorjeta.universe, .1, 3)
gorjeta['media'] = fuzz.gaussmf(gorjeta.universe, 15,5)
gorjeta['alta'] = fuzz.gaussmf(gorjeta.universe, 30,5)
"""